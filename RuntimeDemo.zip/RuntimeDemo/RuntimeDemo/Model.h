//
//  Model.h
//  RuntimeDemo
//
//  Created by BWF-HHW on 16/8/4.
//  Copyright © 2016年 HHW. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Model : NSObject


@property (nonatomic, copy) NSString *name;


- (void)func1;
- (void)func2;



@end
