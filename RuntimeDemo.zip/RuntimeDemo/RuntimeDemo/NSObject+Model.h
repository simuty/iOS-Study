//
//  NSObject+Model.h
//  RuntimeDemo
//
//  Created by BWF-HHW on 16/8/4.
//  Copyright © 2016年 HHW. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSObject (Model)

@property (nonatomic,assign)float height;

@end
